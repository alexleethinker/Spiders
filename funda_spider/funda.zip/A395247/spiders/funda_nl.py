from __future__ import absolute_import

from scrapy import Request
from scrapy.linkextractors import LinkExtractor
from scrapy.loader import ItemLoader
from scrapy.loader.processors import Identity
from scrapy.spiders import Rule

from ..utils.spiders import BasePortiaSpider
from ..utils.starturls import FeedGenerator, FragmentGenerator
from ..utils.processors import Item, Field, Text, Number, Price, Date, Url, Image, Regex
from ..items import PortiaItem


class FundaNl(BasePortiaSpider):
    name = "www.funda.nl"
    allowed_domains = [u'www.funda.nl']
    start_urls = [u'https://www.funda.nl/en/koop/heel-nederland/']
    rules = [
        Rule(
            LinkExtractor(
                allow=('.*'),
                deny=()
            ),
            callback='parse_item',
            follow=True
        )
    ]
    items = [[Item(PortiaItem,
                   None,
                   u'ol:nth-child(3) > li:nth-child(1) > .search-result-main > .search-result-content > .search-result-content-inner > .search-result-info-price',
                   [Field(u'field1',
                          '.search-result-price *::text',
                          [])]),
              Item(PortiaItem,
                   None,
                   u'ol:nth-child(3) > li:nth-child(1) > .search-result-main > .search-result-media > a > .search-result-image',
                   [Field(u'field1',
                          'img::attr(src)',
                          [Url()])]),
              Item(PortiaItem,
                   None,
                   u'ol:nth-child(3) > li:nth-child(1) > .search-result-main > .search-result-content > .search-result-content-inner',
                   [Field(u'field1',
                          '.search-result-header *::text',
                          [])])]]
